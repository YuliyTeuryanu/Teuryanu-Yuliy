import tkinter as tk
from tkinter import messagebox
import requests
import json


def get_repo_info():
    repo_name = entry.get()
    if not repo_name:
        messagebox.showwarning("Внимание", "Введите имя репозитория")
        return

    url = f'https://api.github.com/repos/{repo_name}'
    response = requests.get(url)

    if response.status_code == 200:
        repo_data = response.json()
        output_data = {
            'company': None,
            'created_at': repo_data.get('created_at'),
            'email': None,
            'id': repo_data.get('id'),
            'name': repo_data.get('name'),
            'url': repo_data.get('owner', {}).get('url')
        }

        
        with open('repo_info.json', 'w') as outfile:
            json.dump(output_data, outfile, indent=4)

        messagebox.showinfo("Информация", "Данные успешно получены и записаны в файл 'repo_info.json'")
    else:
        messagebox.showerror("Ошибка", f"Не удалось получить данные: {response.status_code}")


root = tk.Tk()
root.title("GitHub Repo Info")

label = tk.Label(root, text="Введите имя репозитория (например: kubernetes/kubernetes):")
label.pack()

entry = tk.Entry(root, width=50)
entry.pack()

button = tk.Button(root, text="Получить информацию", command=get_repo_info)
button.pack()

root.mainloop()