def print_odd_position_numbers(numbers, index=0):
    if index >= len(numbers):  
        return
    if numbers[index] == 0:  
        return
    if index % 2 == 0:  
        print(numbers[index])  
    print_odd_position_numbers(numbers, index + 1)  


input_numbers = []
while True:
    num = int(input("Введите число (0 для завершения): "))
    if num == 0:  
        break
    input_numbers.append(num)


print_odd_position_numbers(input_numbers)

